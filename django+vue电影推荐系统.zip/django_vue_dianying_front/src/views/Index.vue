<template>
  <div class="index-page">
    <!-- <div class="bottom-right">

      </div> -->


    <div class="index-right">
        <!-- <div style="width: 200px;">
                  <el-input placeholder="搜索" v-model="searchValue" @keyup.enter.native="searchIdle">
                      <el-button slot="append" icon="el-icon-search" @click="searchIdle">搜索</el-button>
                  </el-input>
        </div> -->

        <!-- 轮播图 -->
        <div >
          <el-carousel direction="horizontal" :autoplay="true">
              <el-carousel-item v-for="(v,k) in items" :key="k">
              <img :src="Host+'/upimg/' + v.img_url" style="object-fit: cover;" alt="请检查网络连接">
              </el-carousel-item>
          </el-carousel>
        </div>

        <div style="margin-top:12px">
          <el-tabs v-model="activeName">
            <el-tab-pane label="最新" name="最新"></el-tab-pane>
            <el-tab-pane label="B站程序员科科" name="B站程序员科科"></el-tab-pane>
            <el-tab-pane label="V:python_kk" name="V:python_kk"></el-tab-pane>
          </el-tabs>
        </div>
        <div class="card-box">
          <div style="text-align: center;" class="card-item" v-for="item in tableData" :key="item.id" @click="goDetailPage(item.id)">
            <div class="img-box">
              <img :src="Host+'/upimg/' + item.img_url" width="270" height="200" style="object-fit: cover;">
            </div>
            <div class="card-title">{{ item.name }}</div>
            <div class="card-desc">{{ item.dengji }}</div>
          </div>
      </div>

      <!-- 分页 -->
      <el-pagination background @size-change="handleSizeChange" @current-change="handleCurrentChange"
      layout="sizes, total, prev, pager, next" :total="totalNum" :currentPage="search.pageNum"
      :pageSize="search.pageSize" style="margin-top:20px;margin-left: 200px;">
    </el-pagination>

    </div>

    <div class="index-left" style="text-align: center;">

      <div style="font-weight: 600;font-size: 16px;line-height: 26px;color: #152844;">协同过滤推荐</div>
        <el-divider style="margin-top: 5px" />
        <div>
          <div style="text-align: center;" v-for="item in xtgldata" :key="item.id"  @click="goDetailPage(item.id)">
            <div style="">
              <img :src="Host+'/upimg/' + item.img_url" width="200" height="170"
            style="object-fit: cover;">
            </div>
            <div style="padding: 1px 0;font-weight: 600;font-size: 15px;">{{ item.name }}</div>
            <div style="margin-bottom: 5px;font-size: 10px;">{{ item.dengji }} - {{ item.price }}元</div>
            <br>
          </div>
        </div>

        <el-divider />

        <h4>分类</h4>
        <div style="padding-left: 1rem;display: flex;flex-direction: column;">
          <div style="margin-left: 70px;"  class="row-nav" @click="flquanbu()">全部</div>
          <div style="margin-left: 70px;" class="card-item" v-for="item in fldata" :key="item.id" @click="flshaixuan(item.id)">
            <div class="row-nav">{{ item.mingcheng }}</div>
          </div>
        </div>


      <el-divider />
      <h4>热门地区</h4>
      <div style="display: flex;flex-wrap: wrap;">
        <div class="card-item" v-for="item in dqdata" :key="item.id" @click="dqshaixuan(item.id)">
          <div class="tag-item">{{ item.mingcheng }}</div>
        </div>
      </div>
    </div>

  </div>
</template>

<script>
export default {
  data() {
    return {
      activeName: '最新',
      search: {
        pageNum: 1,
        pageSize: 9,
        fl: '0',
        dq: '0',
        // token: "",
      },
      // 景区
      tableData: [],
      // 景区总数
      totalNum: 0,
      // 景区分类
      fldata: [],
      // 景区地区
      dqdata: [],
      // 景区协同过滤算法算法
      xtgldata: [],
      // 轮播图
      items: [],
    }
  },
  created() {
    this.userInfo = localStorage.getItem("userInfo");
    this.userInfoid = localStorage.getItem("userInfoid");
    this.isAdmin = localStorage.getItem("isAdmin");
    // 景区
    this.getList();
    // 景区分类
    this.getfl();
    // 景区地区
    this.getdq();
    // 景区协同过滤算法
    this.xtgl();
    // 景区轮播图
    this.lb();
  },
  methods: {
    goDetailPage(id){
      // 在新的窗口打开
      this.$router.push({path: '/home/detail', query: {id:id}});
      // window.open('/home/detail')
    },

    // 搜索
    async searchIdle(){

    },

    // 景区轮播图
    lb() {
      this.$api.lb({
        pageNum: this.search.pageNum,
        pageSize: this.search.pageSize,
      }).then(res => {
        if (res.data.code === 200) {
          console.log(res.data.data)
          this.items = res.data.data;
        } else {
        }
      })
    },

    // 全部分类查看
    flquanbu() {
      this.$api.flquanbu({
        pageNum: this.search.pageNum,
        pageSize: this.search.pageSize,
        fl: '0',
        dq: '0',
      }).then(res => {
        if (res.data.code === 200) {
          this.tableData = res.data.data;
          this.totalNum = res.data.zs
          this.$message.success("分类重置成功")
        } else {
        }
      })
    },

    // // 全部分类查看
    // async flquanbu(){
      
    //   const res = await this.$request.get(
    //     "/django_vue_lvyou/jqysh/",
    //     { params: this.search }
    //   );
    //   if (res.data.code === 200) {    
    //     console.log(res.data)
    //     this.tableData = res.data.data;
    //     this.totalNum = res.data.zs
    //   }
    //   this.$message.success("分类重置成功")
    // },

    // 分类筛选
    flshaixuan(item) {
      this.$api.flshaixuan({
        pageNum: this.search.pageNum,
        pageSize: this.search.pageSize,
        fl: item
      }).then(res => {
        if (res.data.code === 200) {
          this.tableData = res.data.data;
          this.totalNum = res.data.zs
          this.$message.success("分类筛选成功")
        } else {
        }
      })
    },

    // 地区筛选
    dqshaixuan(item) {
      this.$api.dqshaixuan({
        pageNum: this.search.pageNum,
        pageSize: this.search.pageSize,
        dq: item
      }).then(res => {
        if (res.data.code === 200) {
          this.tableData = res.data.data;
          this.totalNum = res.data.zs
          this.$message.success("地区筛选成功")
        } else {
        }
      })
    },

    // 已审核景区
    getList(item) {
      this.$api.getList({
        pageNum: this.search.pageNum,
        pageSize: this.search.pageSize,
      }).then(res => {
        if (res.data.code === 200) {
          this.tableData = res.data.data;
          this.totalNum = res.data.zs
        } else {
        }
      })
    },

    // 分类接口
    getfl() {
      this.$api.getfl({
        pageNum: this.search.pageNum,
        pageSize: this.search.pageSize,
      }).then(res => {
        if (res.data.code === 200) {
          this.fldata = res.data.data;
        } else {
        }
      })
    },

    // 地区接口
    getdq() {
      this.$api.getdq({
        pageNum: this.search.pageNum,
        pageSize: this.search.pageSize,
      }).then(res => {
        if (res.data.code === 200) {
          this.dqdata = res.data.data;
        } else {
        }
      })
    },

    // 算法接口
    xtgl() {
      this.$api.xtgl({
        pageNum: this.search.pageNum,
        pageSize: this.search.pageSize,
        userInfoid: this.userInfoid
      }).then(res => {
        if (res.data.code === 200) {
          this.xtgldata = res.data.data;
          console.log(res.data.data)
        } else {
        }
      })
    },

    // 每页条数改变时触发 选择一页显示多少行
    handleSizeChange(val) {
      console.log(`每页 ${val} 条`);
      this.search.pageSize = val;
      this.getList();
    },
    // 当前页改变时触发 跳转其他页
    handleCurrentChange(val) {
      console.log(`当前页: ${val}`);
      this.search.pageNum = val;
      this.getList();
    },
    resetSearch() {
      let search = {
        pageNum: this.search.pageNum,
        pageSize: this.search.pageSize,
      };
      this.search = search;
      this.getList();
    },
  }
}
</script>

<style scoped>
.wh-100 {
  width: 100%;
  height: 100%;
}

.index-page {
  display: flex;
}

.index-left {
  height: fit-content;
  width: 220px;
  margin-left: 50px;
  flex-shrink: 0;
}

.index-right {
  flex: 1;
  box-sizing: border-box;
  height: fit-content;
  padding-bottom: 20px;
}

.index-right2 {
  height: fit-content;
  width: 300px;
  margin-left: 32px;
}

.card-box {
  display: grid;
  grid-template-columns: repeat(3, 1fr);
  grid-gap: 30px 16px;
}

.img-box {
  height: 200px;
  background-color: #f5f5f5;
}

.card-item {
  color: #0f1111;
}

.card-title {
  line-height: 32px;
  margin-top: 16px;
  font-size: 20px;
}

.card-desc {
  font-size: 14px;
}

.row-nav {
  padding: 5px;
  margin-bottom: 5px;
  cursor: pointer;
  width: fit-content;
  border-radius: 3px;
  font-size: 14px;
}

.row-nav:hover {
  background-color: #f5f5f5;
}

.row-nav-active {
  background-color: #bae7ff;
}

.tag-item {
  background: #fff;
  border: 1px solid #a1adc6;
  box-sizing: border-box;
  border-radius: 16px;
  height: 20px;
  line-height: 18px;
  padding: 0 8px;
  margin: 8px 8px 0 0;
  cursor: pointer;
  font-size: 12px;
  color: #152833;
}

.tag-item:hover {
  background: #4684e3;
  color: #fff;
  border: 1px solid #4684e3;
}

.tag-item-active {
  background: #4684e3;
  color: #fff;
  border: 1px solid #4684e3;
}
.bottom-right{
  flex-shrink: 0;
  margin-right: 50px;
}
</style>